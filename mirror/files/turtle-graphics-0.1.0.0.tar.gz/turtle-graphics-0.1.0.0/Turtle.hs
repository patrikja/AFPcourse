-- | proper module documentation here
module Turtle (
  -- * The turtle type(s)
  -- Non-exhaustive list of possible types: Turtle, Program, Action, Operation ...
  Program
  
  -- * Primitive operations
  -- , forward
  -- , (>*>)
  -- , ... 

  -- * Derived operations
  -- ...
  
  -- * Run functions
  -- runTextual :: Program -> IO ()
  -- ...
  
  ) where

-- | Description of your type here...
data Program = YourProgramType



