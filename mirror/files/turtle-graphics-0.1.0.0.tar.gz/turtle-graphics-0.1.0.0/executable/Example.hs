module Main where

import TurtleGraphics
import Turtle
-- import TurtleExtras

main = runGraphical coolExample

coolExample = undefined

