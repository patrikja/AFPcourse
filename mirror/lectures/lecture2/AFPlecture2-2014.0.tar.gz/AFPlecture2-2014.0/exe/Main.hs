module Main where
import Example
main = runExample
